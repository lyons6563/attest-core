To verify this receipt:
1. Load attestation.json and remove the top-level "attestation_hash" field if present.
2. Serialize the resulting object to canonical JSON: sort all object keys, use no whitespace (e.g. separators=(",", ":")), and encode as UTF-8.
3. Compute SHA-256 over that UTF-8 byte string and format as "sha256:<hex>".
4. Compare to the attestation_hash in the file—they must match.
No trust in the producer is required: anyone can recompute the hash from the published attestation and confirm integrity.
